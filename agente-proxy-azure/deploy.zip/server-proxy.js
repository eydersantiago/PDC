import http from "node:http";
import https from "node:https";
import express from "express";

const BACKEND = process.env.BACKEND_BASE || "http://pc-agent.local:3000";
// Ej: BACKEND_BASE=http://pc-agent.local:3000 (mismo host/puerto de la Hybrid Connection)

const app = express();

// Proxy transparente: sirve JSON y multipart sin tocar el body
app.use((req, res) => {
  const target = new URL(req.url, BACKEND);
  const client = target.protocol === "https:" ? https : http;

  const opts = {
    method: req.method,
    headers: { ...req.headers, host: target.host }
  };

  const p = client.request(target, opts, pr => {
    res.writeHead(pr.statusCode || 502, pr.headers);
    pr.pipe(res);
  });

  p.on("error", e => {
    res.writeHead(502, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: false, error: String(e) }));
  });

  req.pipe(p);
});

const port = process.env.PORT || 8080; // Azure asigna PORT
app.listen(port, "0.0.0.0", () =>
  console.log(`Azure proxy escuchando en ${port} → ${BACKEND}`)
);
